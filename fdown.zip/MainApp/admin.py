from django.contrib import admin
from .models import Camera_One_Image, Camera_Two_Image, StateModel
# Register your models here.



admin.site.register(Camera_One_Image)
admin.site.register(Camera_Two_Image)
admin.site.register(StateModel)
